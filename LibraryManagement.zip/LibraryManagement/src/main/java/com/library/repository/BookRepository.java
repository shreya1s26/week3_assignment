package com.library.repository;

public class BookRepository {
    public void fetchBook() {
        System.out.println("Fetching book from repository...");
    }
}
